//
//  CocktailsJson.swift
//  TalesAndSpirits
//
//  Created by Prodip Guha Roy on 2/9/20.
//  Copyright © 2020 RMIT. All rights reserved.
//

import Foundation

struct CocktailsJson: Codable {
    var drinks: [CocktailJson]
}
