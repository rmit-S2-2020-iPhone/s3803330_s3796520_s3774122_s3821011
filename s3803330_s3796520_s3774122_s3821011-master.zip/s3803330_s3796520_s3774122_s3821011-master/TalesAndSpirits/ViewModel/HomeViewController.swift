//
//  HomeViewController.swift
//  TalesAndSpirits
//
//  Created by Prodip Guha Roy on 23/8/20.
//  Copyright © 2020 RMIT. All rights reserved.
//

import UIKit

class HomeViewController: UIViewController, UICollectionViewDelegate, UICollectionViewDataSource, UICollectionViewDelegateFlowLayout, UISearchBarDelegate, RefreshData{
    
    @IBOutlet weak var searchBar: UISearchBar!
    var cocktailViewModel: CocktailViewModel?
    //var filterViewModel: CocktailViewModel?
    
    var searchStatus = false
    var filterCocktail:[Cocktail] = []
    
    @IBOutlet weak var collectionView: UICollectionView!
    
    @IBOutlet weak var dataCollectionCell: DataCollectionView!
    var collectionViewFlowLayout: UICollectionViewFlowLayout!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        cocktailViewModel?.delegate = self
        //filterViewModel?.delegate = self
        searchBar.delegate = self
    }
    
    func updateUIWithRestData() {
        self.collectionView.reloadData()
    }
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        if searchStatus == true {
            return filterCocktail.count + 1
        }
        else {
            return cocktailViewModel!.count + 1
        }
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        if indexPath.row == 0 {
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "labelCollectionView", for: indexPath)as? DataCollectionView
            cell?.titleText.isUserInteractionEnabled = false
            return cell!
            
        }else{
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "collectionView", for: indexPath)as? DataCollectionView
            if searchStatus == true{
                /*let url = filterCocktail[indexPath.item - 1]._imageName
                let imageURL = URL(string: url)
                let data = try? Data(contentsOf: imageURL!)
                if let imageData = data{
                    cell?.imageView?.image = UIImage(data: imageData)
                }
                cell?.nameLabel?.text = filterCocktail[indexPath.item - 1]._cocktailName*/
                
                for element in 0..<filterCocktail.count{
                    let itemIndex = cocktailViewModel?.getCocktailIndex(newCocktail: filterCocktail[element])
                    cell!.imageView.image = cocktailViewModel!.getCocktailImage(byIndex: itemIndex!)
                    cell!.nameLabel.text = cocktailViewModel!.getCocktailName(byIndex: itemIndex!)
                }
            }
            else{
                if let cell = cell, let cocktailViewModel = cocktailViewModel{
                    cell.imageView.image = cocktailViewModel.getCocktailImage(byIndex: (indexPath.item - 1))
                    cell.nameLabel.text = cocktailViewModel.getCocktailName(byIndex: (indexPath.item - 1))
                }
            }
            return cell!
        }
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        let bounds = collectionView.bounds
        let position = indexPath.row
        if(position == 0){return CGSize(width: bounds.width, height: 60)}
        else{
            return CGSize(width: bounds.width/2, height: 160)}
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumLineSpacingForSectionAt section: Int) -> CGFloat {
        return 0
    }
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumInteritemSpacingForSectionAt section: Int) -> CGFloat {
        return 0
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if searchStatus == true{
            //guard let selectedItem = self.collectionView.indexPathsForSelectedItems?.first else {return}
            let newDestination = segue.destination as? RecipeSceneViewController
            
            for element in 0..<filterCocktail.count{
                let itemIndex = (cocktailViewModel?.getCocktailIndex(newCocktail: filterCocktail[element]))!
                cocktailViewModel?.fetchCocktailById(index: itemIndex)
                newDestination!.cocktailViewModel = cocktailViewModel
                newDestination!.index = itemIndex
                //newDestination!.index = selectedItem.item - 2
                
            }
        }
        else{
            guard let selectedItem = self.collectionView.indexPathsForSelectedItems?.first else {return}
            let newDestination = segue.destination as? RecipeSceneViewController
            
            if let newDestination = newDestination{
                cocktailViewModel?.fetchCocktailById(index: selectedItem.item - 1)
                newDestination.cocktailViewModel = cocktailViewModel
                newDestination.index = selectedItem.item - 1
            }
        }
    }
    
    func searchBar(_ searchBar: UISearchBar, textDidChange searchText: String) {
        
        if searchText.isEmpty {
            searchStatus = false
            searchBar.text = ""
            searchBar.endEditing(true)
            self.collectionView.reloadData()
        }else {
            searchStatus = true
            filterCocktail = (cocktailViewModel?.filter(searchText: searchText))!
            self.collectionView.reloadData()
        }
        
        func searchBarSearchButtonClicked(_ searchBar: UISearchBar) {
            searchStatus = true
            filterCocktail = (cocktailViewModel?.filter(searchText: searchText))!
            self.collectionView.reloadData()
            searchBar.resignFirstResponder()
        }
        
        func searchBarTextDidEndEditing(_ searchBar: UISearchBar) {
            searchStatus = false
            searchBar.text = ""
            searchBar.endEditing(true)
            searchBar.resignFirstResponder()
            self.collectionView.reloadData()
        }
    }
}
