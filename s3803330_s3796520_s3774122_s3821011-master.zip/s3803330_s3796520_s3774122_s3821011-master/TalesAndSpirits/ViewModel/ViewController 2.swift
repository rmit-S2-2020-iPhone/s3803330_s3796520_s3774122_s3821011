//
//  ViewController.swift
//  TalesAndSpirits
//
//  Created by PUJA on 14/8/20.
//  Copyright © 2020 RMIT. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

