# s3803330_s3796520_s3774122_s3821011

## Tales and Sprits

Tales and Spirits is the one of a kind Cocktail recipe app which is inspired. With its sleek and
clean user friendly interface, user can look for great cocktails in no time. Throughout the app, all pages
are carefully crafted for the best experience. It has tons of features which we believe will be
loved by our user.Tales and Spirits

By Team - 

s3803330_Ankit 

s3796520_Gajendra 

s3774122_Henry 

s3821011_Prodip

To run app - 

1. Use xcode 10.3 & swift 4 for best results.

2. Download and unzip the project.

3. Open project in xcode and press run.
